// Paste your full JavaScript code here
